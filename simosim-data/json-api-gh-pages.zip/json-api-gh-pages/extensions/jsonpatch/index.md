---
layout: page
title: "JSON Patch Extension"
redirect_to: /extensions/#prior-extensions
---
